Only Enterprise License contains both the .fla and .as files. 

Developer/Professional/Site license contains .as files only, which can be used to embed the charts in your Flash movies.