#!/usr/bin/perl

use strict;
use lib '/opt/qc_automation';
use QC;

my $qc = new QC();

$qc->start_ssh_session( "72.52.77.131", "root", "^sunshine3" );

$qc->section2_check_patch_version();

$qc->section2_check_iq_services_started();
