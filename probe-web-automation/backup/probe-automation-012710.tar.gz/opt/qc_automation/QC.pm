#!/usr/bin/perl
# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4 foldmethod=marker: #

package QC;
use strict;
use Expect;

# {{{ new
sub new {
    my $self  = {};

    $self->{ssh} = undef;
    $self->{ip} = undef;
    $self->{user} = undef;
    $self->{password} = undef;

    bless($self);
        
    return $self;
}
# }}}

sub start_ssh_session {

    my $self = shift;

    $self->{ip} = $_[0];
    $self->{user} = $_[1];
    $self->{password} = $_[2];

    my $command = "/usr/bin/ssh ".$self->{user}."\@".$self->{ip}."\n";    

    $self->{ssh} = new Expect;

    #$self->{ssh}->raw_pty(1);
    $self->{ssh}->log_stdout(0); # Turn off output the to screen

    # Login to the remote system
    $self->{ssh}->spawn( $command ) 
        or die "Cannot spawn $command: $!\n";
    
    $self->{ssh}->expect( 10, '-re', '^.* password:' );

    $self->{ssh}->send( $self->{password}."\n" );

    $self->{ssh}->expect( 10, '-re', '$\$|$#' );

} 

sub section2_check_patch_version {

    my $self = shift;

    $self->{ssh}->send( "cat /opt/ineoquest/ivms-default/version.txt \n" );

    $self->{ssh}->expect(1);

    my $read = $self->{ssh}->before(); # Grab Output From Command

    print $read;
}
sub section2_check_iq_services_started {

    my $self = shift;

    $self->{ssh}->send( "/etc/init.d/ivms-all status \n" );

    $self->{ssh}->expect(10);

    my $read = $self->{ssh}->before(); # Grab Output From Command

    print $read;
}
sub section2_check_xml_check_external_address{

    my $self = shift;                                                                   
                                                                                        
    $self->{ssh}->send( "cat /opt/ineoquest/ivms-default/ineoQuestNMS/conf/IQGuardianSettings.xml | grep \"server_config\" \n" );                             
                                                                                        
    $self->{ssh}->expect(10);                                                           

    my $read = $self->{ssh}->before(); # Grab Output From Command                       
    
    print $read;
}
sub section2_check_xml_smtp_config{

    my $self = shift;
 
    $self->{ssh}->send( "cat /opt/ineoquest/ivms-default/ineoQuestNMS/conf/IQGuardianSettings.xml | grep \"smtp_server smtpServer\" \n" );

    $self->{ssh}->expect(10);

    my $read = $self->{ssh}->before(); # Grab Output From Command                       

    print $read;
}
sub section2_get_retentionPeriod{

    my $self = shift;
 
    $self->{ssh}->send( "cat /opt/ineoquest/ivms-default/ineoQuestNMS/conf/IQDBPurgeSettings.xml | grep \"retentionPeriod\" \n" );

    $self->{ssh}->expect(10);

    my $read = $self->{ssh}->before(); # Grab Output From Command                       

    print $read;
}

1;
