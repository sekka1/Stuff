#!/usr/bin/perl

use strict;
use lib '/opt/qc_automation';
use QC_WEB;

my @return1 = undef;

$return1[0]['zero'] = 'zero';
$return1[1]['one'] = 'one';

print $return1[0]['zero'];
