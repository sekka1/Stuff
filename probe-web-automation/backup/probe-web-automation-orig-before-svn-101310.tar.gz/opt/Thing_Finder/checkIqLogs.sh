export LOGDIR=/opt/ineoquest/ivms-default/logs
LOGFILES=`ls -lr --sort=time $LOGDIR/IQ[A-GS-U]*/*.txt $LOGDIR/IQMo*/*.txt $LOGDIR/IQNorth*/*.txt $LOGDIR/IQGuardianDBCl*/*.txt $LOGDIR/../apache/logs/*.log $* | awk '{print $9}'`
tail -f $LOGFILES
